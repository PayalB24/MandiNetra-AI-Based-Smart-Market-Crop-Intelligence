import requests
from Mandi_Chatbot.config import WEATHER_API_KEY
# 🔥 CITY BASED WEATHER (fallback)
def get_weather(city="Kopargaon"):
    try:
        url = f"http://api.openweathermap.org/data/2.5/weather?q={city}&appid={WEATHER_API_KEY}&units=metric"

        res = requests.get(url)
        data = res.json()

        weather = data["weather"][0]["description"]
        temp = data["main"]["temp"]

        return f"{weather}, {temp}°C"

    except Exception as e:
        print("Weather error:", e)
        return "Weather not available"


# 🔥 LOCATION BASED WEATHER
def get_weather_by_location(lat, lon):
    try:
        url = f"http://api.openweathermap.org/data/2.5/weather?lat={lat}&lon={lon}&appid={WEATHER_API_KEY}&units=metric"

        res = requests.get(url)
        data = res.json()

        weather = data["weather"][0]["description"]
        temp = data["main"]["temp"]

        return f"{weather}, {temp}°C"

    except Exception as e:
        print("Weather error:", e)
        return "Weather not available"