import requests
from Mandi_Chatbot.config import GEOCODING_API_KEY

def get_district(lat, lon):
    try:
        url = f"https://us1.locationiq.com/v1/reverse.php?key={GEOCODING_API_KEY}&lat={lat}&lon={lon}&format=json"

        res = requests.get(url)
        data = res.json()

        address = data.get("address", {})

        # try district first
        district = address.get("county") or address.get("state_district") or address.get("city")

        return district if district else "Pune"

    except Exception as e:
        print("LocationIQ Error:", e)
        return "Pune"