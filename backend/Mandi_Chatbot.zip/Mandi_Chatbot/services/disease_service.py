import requests
from Mandi_Chatbot.config import PLANTNET_API_KEY

def predict_disease(image_path):
    try:
        url = f"https://my-api.plantnet.org/v2/identify/all?api-key={PLANTNET_API_KEY}"

        files = {
            "images": open(image_path, "rb")
        }

        data = {
            "organs": ["leaf"]
        }

        response = requests.post(url, files=files, data=data)
        result = response.json()

        results = result.get("results", [])

        if results:
            top = results[0]

            plant_name = top["species"]["scientificNameWithoutAuthor"]
            common_names = top["species"].get("commonNames", [])
            confidence = round(top["score"] * 100, 2)

            name = common_names[0] if common_names else plant_name

            return f"""
🌿 Plant: {name}
📊 Confidence: {confidence}%

⚠️ Check leaf condition for disease symptoms.
💡 Suggestion: Use proper pesticide & avoid overwatering.
"""

        return "❌ No plant detected"

    except Exception as e:
        print("PlantNet Error:", e)
        return "⚠️ Disease detection failed"