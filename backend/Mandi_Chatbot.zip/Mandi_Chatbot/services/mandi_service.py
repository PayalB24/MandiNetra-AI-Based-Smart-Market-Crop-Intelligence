import requests
import json
from datetime import datetime
from Mandi_Chatbot.config import DATA_GOV_API_KEY

# 🔥 MULTI-LANGUAGE CROP MAP
CROP_MAP = {
    "wheat": "Wheat",
    "गहू": "Wheat",
    "गेहूं": "Wheat",

    "rice": "Paddy(Dhan)",
    "भात": "Paddy(Dhan)",
    "चावल": "Paddy(Dhan)",

    "onion": "Onion",
    "कांदा": "Onion",
    "प्याज": "Onion",

    "tomato": "Tomato",
    "टोमॅटो": "Tomato",
    "टमाटर": "Tomato",

    "potato": "Potato",
    "आलू": "Potato",
    "बटाटा": "Potato",

    "cotton": "Cotton",
    "कापूस": "Cotton",

    "bajra": "Bajra",
    "बाजरी": "Bajra"
}


def get_crop_price(crop, state="Maharashtra", district=None):
    try:
        crop_name = CROP_MAP.get(crop.lower(), crop)

        url = "https://api.data.gov.in/resource/9ef84268-d588-465a-a308-a864a43d0070"

        params = {
            "api-key": DATA_GOV_API_KEY,
            "format": "json",
            "limit": 50,
            "filters[commodity]": crop_name,
            "filters[state]": state
        }

        if district:
            params["filters[district]"] = district

        response = requests.get(url, params=params, timeout=5)
        data = response.json()

        records = data.get("records", [])

        # ❌ If API has no data → fallback JSON
        if not records:
            return get_price_from_json(crop_name, district)

        # ✅ FIX: Proper date sorting
        latest = sorted(
            records,
            key=lambda x: datetime.strptime(x["arrival_date"], "%d/%m/%Y"),
            reverse=True
        )[0]

        price = latest.get("modal_price", "N/A")
        market = latest.get("market", "Unknown")
        date = latest.get("arrival_date", "")

        return f"{crop_name} price is ₹{price}/quintal in {market} on {date}"

    except Exception as e:
        print("API ERROR:", e)

        # 🔥 fallback if API fails
        return get_price_from_json(crop, district)


# =====================================================
# 🔥 JSON FALLBACK FUNCTION
# =====================================================
def get_price_from_json(crop_name, district=None):
    try:
        with open("Mandi_Chatbot/data/mandi_prices.json") as f:
            data = json.load(f)

        crop_data = data.get(crop_name)

        if not crop_data:
            return f"No price data available for {crop_name}"

        if district and district in crop_data:
            return f"{crop_name} price in {district}: {crop_data[district]}"

        # return first available district
        district_name = list(crop_data.keys())[0]
        price = crop_data[district_name]

        return f"{crop_name} price in {district_name}: {price}"

    except Exception as e:
        print("JSON ERROR:", e)
        return "Price data not available"