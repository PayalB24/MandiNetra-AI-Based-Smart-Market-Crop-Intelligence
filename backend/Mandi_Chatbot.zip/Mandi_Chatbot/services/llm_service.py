from groq import Groq
from Mandi_Chatbot.config import GROQ_API_KEY

client = Groq(api_key=GROQ_API_KEY)

def generate_response(user_input):
    try:
        response = client.chat.completions.create(
        model="llama-3.3-70b-versatile"      ,
        messages=[
                {
                    "role": "system",
                    "content": "You are an agriculture expert. Give simple advice to farmers."
                },
                {
                    "role": "user",
                    "content": user_input
                }
            ]
        )

        return response.choices[0].message.content

    except Exception as e:
        print("ERROR:", e)
        return "AI Error"

