import os

from flask import Blueprint, request, jsonify
from Mandi_Chatbot.services.llm_service import generate_response
from Mandi_Chatbot.services.translate_service import translate_text
from Mandi_Chatbot.services.weather_service import get_weather, get_weather_by_location
from Mandi_Chatbot.services.mandi_service import get_crop_price
from Mandi_Chatbot.services.location_service import get_district
from Mandi_Chatbot.services.disease_service import predict_disease  

chatbot_bp = Blueprint("chatbot", __name__)

# =====================================================
# 🌾 MAIN CHAT ROUTE
# =====================================================
@chatbot_bp.route("/chat", methods=["POST"])
def chat():
    data = request.json

    user_msg = data.get("message")
    user_lang = data.get("language", "en")

    # ✅ SAFE LOCATION FIX
    location = data.get("location") or {}
    lat = location.get("lat")
    lon = location.get("lon")

    if not user_msg:
        return jsonify({"reply": "Please enter a message"}), 400

    try:
        english_msg = translate_text(user_msg, "en") if user_lang != "en" else user_msg
        msg = english_msg.lower()

        # =========================
        # 🌾 MANDI PRICE
        # =========================
        if any(word in msg for word in ["price", "rate", "mandi", "market", "भाव", "रेट"]):

            district = get_district(lat, lon) if lat and lon else None
            price_data = get_crop_price(english_msg, district=district)

            ai_response = f"{price_data}\n\n💡 Tip: Sell when price is high."

        # =========================
        # 🌦️ WEATHER
        # =========================
        elif any(word in msg for word in ["weather", "rain", "fertilizer", "spray", "irrigation", "पाऊस"]):

            weather_data = get_weather_by_location(lat, lon) if lat and lon else get_weather("Pune")

            ai_response = generate_response(f"""
User: {english_msg}
Weather: {weather_data}

Give short farming advice.
""")

        # =========================
        # 🌿 DISEASE MESSAGE
        # =========================
        elif "disease" in msg or "leaf" in msg:
            ai_response = "📸 Please upload crop image for disease detection."

        else:
            ai_response = generate_response(english_msg)

        final_response = translate_text(ai_response, user_lang) if user_lang != "en" else ai_response

        return jsonify({"reply": final_response})

    except Exception as e:
        print("Error:", e)
        return jsonify({"reply": "⚠️ Server error"}), 500


# =====================================================
# 🦠 DISEASE IMAGE UPLOAD ROUTE
# =====================================================
@chatbot_bp.route("/detect-disease", methods=["POST"])
def detect_disease():
    try:
        file = request.files["image"]

        # ✅ SAFE FOLDER FIX
        os.makedirs("Mandi_Chatbot/temp", exist_ok=True)

        filepath = f"Mandi_Chatbot/temp/{file.filename}"
        file.save(filepath)

        result = predict_disease(filepath)

        return jsonify({"reply": result})

    except Exception as e:
        print("Error:", e)
        return jsonify({"reply": "Error processing image"}), 500