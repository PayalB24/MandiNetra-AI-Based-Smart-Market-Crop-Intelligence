import React, { useState, useEffect, useRef } from "react";
import "./Chatbot.css";
import { useTranslation } from "react-i18next";
import LanguageSelector from "./LanguageSelector";
import VoiceInput from "./VoiceInput";

const Chatbot = () => {
  const { t, i18n } = useTranslation(["chatbot"]);

  const [messages, setMessages] = useState([]);
  const [input, setInput] = useState("");
  const [language, setLanguage] = useState("en");
  const [typing, setTyping] = useState(false);
  const [location, setLocation] = useState(null);

  const [open, setOpen] = useState(false);
  const [fullScreen, setFullScreen] = useState(false);

  // 🔊 NEW STATES
  const [voiceGender, setVoiceGender] = useState("female");
  const [voiceSpeed, setVoiceSpeed] = useState(1);
  const [voices, setVoices] = useState([]);

  const messagesEndRef = useRef(null);

  // ================= INIT =================
  useEffect(() => {
    setMessages([{ sender: "bot", text: t("chatbot:welcome") }]);
  }, [language, t]);

  // ================= LOAD VOICES =================
  useEffect(() => {
    const loadVoices = () => {
      const v = window.speechSynthesis.getVoices();
      if (v.length > 0) setVoices(v);
    };
    loadVoices();
    window.speechSynthesis.onvoiceschanged = loadVoices;
  }, []);

  // ================= LOCATION =================
  useEffect(() => {
    navigator.geolocation?.getCurrentPosition((pos) => {
      setLocation({
        lat: pos.coords.latitude,
        lon: pos.coords.longitude,
      });
    });
  }, []);

  // ================= AUTO SCROLL =================
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  // ================= API =================
  const sendMessage = async (message) => {
    try {
      const res = await fetch("http://localhost:5000/chatbot/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ message, language, location }),
      });
      return await res.json();
    } catch {
      return { reply: "Server error" };
    }
  };

  // ================= 🔊 BROWSER TTS =================
  const speak = (text) => {
    if (!window.speechSynthesis) return;

    const utterance = new SpeechSynthesisUtterance(text);

    // language
    utterance.lang =
      language === "hi"
        ? "hi-IN"
        : language === "mr"
        ? "mr-IN"
        : "en-IN";

    // speed
    utterance.rate = voiceSpeed;

    // 🎯 voice selection
    let selectedVoice;

    if (voiceGender === "female") {
      selectedVoice = voices.find((v) =>
        v.name.toLowerCase().includes("female")
      );
    } else {
      selectedVoice = voices.find((v) =>
        v.name.toLowerCase().includes("male")
      );
    }

    // fallback
    if (!selectedVoice) {
      selectedVoice = voices.find((v) =>
        v.lang.includes(utterance.lang)
      );
    }

    if (selectedVoice) utterance.voice = selectedVoice;

    window.speechSynthesis.cancel();
    window.speechSynthesis.speak(utterance);
  };

  // ================= SEND =================
  const handleSend = async () => {
    if (!input.trim()) return;

    const userMsg = input;

    setMessages((prev) => [...prev, { sender: "user", text: userMsg }]);

    setTyping(true);
    const data = await sendMessage(userMsg);
    setTyping(false);

    setMessages((prev) => [...prev, { sender: "bot", text: data.reply }]);

    setInput("");
  };

  // ================= IMAGE =================
  const uploadImage = async (file) => {
    const formData = new FormData();
    formData.append("image", file);

    const res = await fetch("http://localhost:5000/chatbot/detect-disease", {
      method: "POST",
      body: formData,
    });

    const data = await res.json();

    setMessages((prev) => [
      ...prev,
      { sender: "bot", text: data.reply },
    ]);
  };

  return (
    <>
      {/* FLOAT BUTTON */}
      <div className="chatbot-float-btn" onClick={() => setOpen(!open)}>
        💬
      </div>

      {open && (
        <div className={`chatbot-container ${fullScreen ? "full-screen" : ""}`}>

          {/* HEADER */}
          <div className="chatbot-header">
            🌾 MandiNetra AI

            <div style={{ display: "flex", gap: "10px" }}>
              <LanguageSelector
                language={language}
                setLanguage={(lang) => {
                  setLanguage(lang);
                  i18n.changeLanguage(lang);
                }}
              />

              <button onClick={() => setFullScreen(!fullScreen)}>
                {fullScreen ? "🗗" : "⛶"}
              </button>

              <button onClick={() => setOpen(false)}>✖️</button>
            </div>
          </div>

          {/* 🎛️ VOICE CONTROLS */}
          <div style={{ display: "flex", gap: "10px", padding: "5px" }}>
            <select
              value={voiceGender}
              onChange={(e) => setVoiceGender(e.target.value)}
            >
              <option value="female">Female</option>
              <option value="male">Male</option>
            </select>

            <input
              type="range"
              min="0.5"
              max="2"
              step="0.1"
              value={voiceSpeed}
              onChange={(e) => setVoiceSpeed(e.target.value)}
            />
          </div>

          {/* MESSAGES */}
          <div className="chatbot-messages">
            {messages.map((msg, i) => (
              <div key={i} className={`msg-bubble ${msg.sender}`}>
                {msg.text}

                {/* ▶️ PLAY BUTTON ONLY */}
                {msg.sender === "bot" && (
                  <button onClick={() => speak(msg.text)}>▶️</button>
                )}
              </div>
            ))}

            {typing && <div className="msg-bubble bot">Typing...</div>}
            <div ref={messagesEndRef} />
          </div>

          {/* INPUT */}
          <div className="chatbot-input">
            <VoiceInput
              language={language}
              onVoiceInput={(text) => setInput(text)}
            />

            <input
              value={input}
              onChange={(e) => setInput(e.target.value)}
              placeholder="Ask something..."
              onKeyDown={(e) => e.key === "Enter" && handleSend()}
            />

            <input
              type="file"
              accept="image/*"
              onChange={(e) => uploadImage(e.target.files[0])}
            />

            <button onClick={handleSend}>Send</button>
          </div>
        </div>
      )}
    </>
  );
};

export default Chatbot;
