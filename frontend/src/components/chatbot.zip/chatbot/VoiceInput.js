import React, { useState, useEffect } from "react";
import "./VoiceInput.css";
import { useTranslation } from "react-i18next";

const VoiceInput = ({ onVoiceInput, language }) => {
  const { t } = useTranslation("voice"); // Specify the voice namespace
  const [isListening, setIsListening] = useState(false);
  const [recognition, setRecognition] = useState(null);
  const [error, setError] = useState("");

  // Language mapping for speech recognition
  const languageMap = {
    en: "en-IN",
    hi: "hi-IN",
    mr: "mr-IN",
  };

  useEffect(() => {
    if (window.SpeechRecognition || window.webkitSpeechRecognition) {
      const SpeechRecognition =
        window.SpeechRecognition || window.webkitSpeechRecognition;
      const recognitionInstance = new SpeechRecognition();

      recognitionInstance.continuous = false;
      recognitionInstance.interimResults = false;
      recognitionInstance.maxAlternatives = 1;

      recognitionInstance.onstart = () => {
        setIsListening(true);
        setError("");
      };

      recognitionInstance.onresult = (event) => {
        const transcript = event.results[0][0].transcript;
        if (transcript.trim()) {
          onVoiceInput(transcript);
        }
        setIsListening(false);
      };

      recognitionInstance.onerror = (event) => {
        setIsListening(false);
        if (event.error === "not-allowed") {
          setError(t("mic_permission"));
        } else if (event.error === "audio-capture") {
          setError(t("no_mic"));
        } else {
          setError(t("recognition_error"));
        }
      };

      recognitionInstance.onend = () => {
        setIsListening(false);
      };

      setRecognition(recognitionInstance);

      return () => {
        recognitionInstance && recognitionInstance.stop();
      };
    } else {
      setError(t("not_supported"));
    }
  }, [onVoiceInput, t]);

  // SECOND useEffect
  useEffect(() => {
    if (recognition && language) {
      recognition.lang = languageMap[language] || "en-IN";
    }
  }, [language, recognition, languageMap]);

  const toggleListening = () => {
    if (!recognition) {
      setError(t("not_supported"));
      return;
    }

    if (isListening) {
      recognition.stop();
      setIsListening(false);
    } else {
      try {
        recognition.start();
      } catch (err) {
        setError(t("start_error"));
      }
    }
  };

  return (
    <div className="voice-input-container">
      <button
        className={`voice-btn ${isListening ? "listening" : ""}`}
        onClick={toggleListening}
        disabled={!!error}
        title={isListening ? t("stop") : t("start")}
      >
        <span className="voice-btn-icon">{isListening ? "⏹️" : "🎤"}</span>
        {isListening && (
          <div className="listening-animation">
            <span className="pulse-ring"></span>
            <span className="pulse-ring delay-1"></span>
            <span className="pulse-ring delay-2"></span>
          </div>
        )}
      </button>

      {error && (
        <div className="voice-error">
          <span className="error-icon">⚠️</span>
          <span className="error-text">{error}</span>
        </div>
      )}

      {isListening && (
        <div className="listening-status">
          <div className="listening-text">{t("listening")}</div>
          <div className="sound-wave">
            <div className="wave-bar"></div>
            <div className="wave-bar"></div>
            <div className="wave-bar"></div>
            <div className="wave-bar"></div>
            <div className="wave-bar"></div>
          </div>
        </div>
      )}
    </div>
  );
};

export default VoiceInput;
